# 第05次作业


###   实现“账号登陆”和“二维码登陆”两个组件的动画切换销毁（结合animate.css动画库实现）
![输入图片说明](https://images.gitee.com/uploads/images/2021/0328/215638_5c89b85a_8679573.png "屏幕截图.png")
